var form = document.getElementById("reddit-form");
var dl = document.getElementById("download-button");
var track_img = document.getElementById("track_img");
var video_subreddit = document.getElementById("video-subreddit"); var mylist = document.getElementById("SongsListArea");
var modalist = document.getElementById("SongsListModel");
var video_title = document.getElementById("video-title");
  var copyText = document.getElementById("view-button");


if (form != undefined) {
  console.log(track)
  var form_message = document.getElementById("form-message");
    var input_els = document.getElementsByClassName("user-input");

  for (var i = 0; i < input_els.length; ++i) {
    input_els[i].addEventListener("change", function(e) {
      e.target.classList.remove("input-error");
      hide_form_message(form_message);
    });
  }

  function validate_form_data(data) {
    return { valid: true };
  }

  form.addEventListener("submit", function(e) {
    e.preventDefault();
    var data = new FormData(form);

    var validation = validate_form_data(data);
    if (validation.valid == false) {
      show_form_message("error", validation.error, form_message, 10000);
      show_input_field_error(document.getElementById(validation.error_fields[0]), 0);
      return;
    }

    document.getElementById("form-content").style.display = "none";
    document.getElementById("loading").style.display = "flex";

    var object = { name:track, url: document.getElementsByClassName("user-input")[0].value }
    console.log(document.getElementsByClassName("user-input")[0].value)
    axios.post('/save/321', object)
      .then(function(res) {
        if(res.data.isUrl == false && res.data.success ){

   res.data.list.forEach((song, index) => {
       mylist.innerHTML +=("<tr id=t_"+(song.id)+"><td class='center aligned'>"+(index+1)+"</td><td class='center aligned'><img style='max-width: 163px;' src="+song.thumbnail.url+"></td><td class='center aligned'>"+song.duration_formatted+"</td><td class='center aligned'>"+song.title+"</td><td class='center aligned'><button class='button icon-button dowload-button'  onclick='download(this)'id="+(song.id)+">Download!</button>"+"</td></tr>")
    })

    
   // modal.setContent(mylist);
sweet("test","<table class='styled-table' id='listTrack'><tbody>"+mylist.outerHTML+"</tbody></table>")
//modal.open();
//return CreativaPopup.create('','','',{ content:"<table class='styled-table' id='listTrack'><tbody>"+mylist.outerHTML+"</tbody></table>",fontFamily: 'Pacifico',boxShadow: '0px 6px 12px 2px #red',borderRadius: '20px',box: true,bgColor: '#a31919',background: true,closeAnimation: 'fade'/*image: response.thumbnail.url*/});


        }
        var response = res.data.current;

        if (res.data.success == false) {
notfic("err","error")
console.log(res.data)
  document.getElementById("form-content").style.display = "block";
          document.getElementById("loading").style.display = "none";

          show_form_message("error", "err", form_message, 10000);

          if (res.data.error_fields.length > 0) {
            for (var i = 0; i < res.data.error_fields.length; ++i) {
              document.getElementById(res.data.error_fields[i]).classList.add("input-error");
            }
          }

     } else {
   dl.setAttribute("href", response.dl);

track_img.src = response.thumbnail.url
video_title.textContent = response.title +" ("+response.duration_formatted+")"
video_subreddit.textContent = response.channel.name 
        document.getElementById("form-content").style.display = "none";
    document.getElementById("loading").style.display = "none";
      document.getElementById("form-content").style.display = "none";
          document.getElementsByClassName("video-info")[0].style.display = "block";

  dl.style.display = "block";
 ///var blop = new Audio( "/"+response.id+".mp3");
   //// blop.loop = true

  ///blop.play()
  document.getElementById("songControl").style.display = "block"
  copyText.dataset.name = response.dl
  copyText.style.display = "block"
var au = document.getElementById("player");


player.source = {
  type: 'audio',
  sources: [
    {
      src: response.dl,
      type: 'audio/mp3',
    },
  ],
};

au.plyr.restart()

au.plyr.play()

notfic(response.title,"info")




      }
        


      })
      .catch(function(error) { });

  });
}
