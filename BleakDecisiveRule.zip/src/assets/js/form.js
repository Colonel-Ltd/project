function show_form_message(type, message, element, show_time) {
    element.classList.remove("hide");
    element.classList.add("show");

    if(type == "error" || type == "success") {
        element.classList.remove("error");
        element.classList.remove("success");
        element.classList.remove("other");
        element.classList.add(type);
    }
    else {
        element.classList.remove("error");
        element.classList.remove("success");
        element.classList.add("other");
    }

    element.innerText = message;

    if(show_time != 0) {
        setTimeout(function(){hide_form_message(element)}, show_time);
    }
}

function hide_form_message(element) {
    element.classList.add("hide");
    element.classList.remove("show");
}

function show_input_field_error(element, show_time) {
    if(element == undefined) {
        return;
    }
    element.classList.add("input-error");
    if(show_time != 0) {
        setTimeout(function(){hide_input_field_error(element)}, show_time);
    }
}

function hide_input_field_error(element) {
    element.classList.remove("input-error");
}