var track = "";
var polipop = new Polipop('mypolipop', {
    layout: 'popups',
    insert: 'before',
    pool: 5,
    sticky: true,
});



function notfic(msg,type) {
polipop.add({
                type: type || "info",
                title: 'Info',
                content: msg,
            });

}


function download(e){
///CreativaPopup.close(1)
Swal.close()	
console.log(e.dataset)
var xc = document.getElementById("t_"+e.id)
console.log(xc)
track = document.getElementById("t_"+e.id).cells[3].innerText



document.getElementsByClassName("user-input")[0].value = e.id 
  document.getElementById("input-copy").click();

}


function myFunction(txt) {
  var copyText = document.getElementById("view-button");
  navigator.clipboard.writeText(copyText.dataset.name);
  
  notfic("copied","info")
  
}
function sweet(html,contentx){
Swal.fire({
               // showConfirmButton: true,
                width: "100%",
                padding: 3,
                html:contentx,
                background: 'rgba(0, 0, 0, 0)'
            })

}

