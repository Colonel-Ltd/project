const { Collection, Client } = require("discord.js");
const client = new Client();//Making a discord bot client
const mysql = require('mysql');
const { Query } = require('mysql-easy-query');
/*
const connection = mysql.createPool({
	host     : 'remotemysql.com',
	user     : 'FNvxuuaqOo',
	password : 'JpXKeAXFTc',
	database : 'FNvxuuaqOo'
});




connection.getConnection(function(err) {
  if (err) throw err;
  console.log("Connected to pool database!");
});
*/

//const q = new Query(connection);

client.commands = new Collection();//Making client.commands as a Discord.js Collection
client.queue = new Map()
//client.db = q

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`);
 let ch = client.channels.cache.get('946773181551742976')
  /*
 ch.send({
   
  embed: {
    thumbnail: {
         url: 'attachment://file.jpg'
      }
   },
   
   files: [{
      attachment: 'routes/mp3/2O2xBY5ptOA.mp3',
      name: 'file.mp3'
   }]
}).then(async (msg) => {
console.log(msg.attachments.array()[0].attachment)
 const builder = q.builder().insert('song', { track_id: msg.id,msg_id:msg.attachments.array()[0].attachment })
 let xxx = await q.query(builder);
 })
 

  .catch(console.error);
*/
});


client.login('OTQ1NTc0NjkwNjk1NTQ0ODYy.YhSJDg.B9QRNqesEOUTK03CIoeLjmFnRxw');


module.exports = client;
