const YouTube = require("youtube-sr").default;
const ytdl = require('ytdl-core');
const fs = require('fs');
let client = require('../bot/bot');
//const decoder = require('lame')
//const speaker = require('speaker')

var path = require('path');
const express = require("express");
var session = require("express-session");
const prettyMilliseconds = require("pretty-ms");
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;

const ffmpeg = require('fluent-ffmpeg');
ffmpeg.setFfmpegPath(ffmpegPath);

const { Webhook } = require('discord-webhook-node');
const hook = new Webhook("https://discord.com/api/webhooks/945552995087712286/8vCh6lvi93sOxDHcQ95dHlrKN5VTiyLHHIESLHUL_s4jWV9MOpbhiUq2nFr9e8a1TRsP");


const router = express.Router();
const videoID = 'http://www.youtube.com/watch?v=';

router.get('/', (req, res) => {
  ///res.send('<center><h3>Yo, Wazzup Homie!</h3></center>')
  res.render("index")
})

router.get('/api', async (req, res) => {
  ///res.send('<center><h3>Yo, Wazzup Homie!</h3></center>')
const filt = client.db.builder().select().from('song')
   let xxx = await client.db.query(filt);
  
  res.send(xxx)
})



router.get('/stream/:id', (req, res) => {
  console.log('video url >> ', videoID + req.params.id);
  const astream = ytdl(videoID + req.params.id, {
    quality: 251
  });
    res.setHeader('Content-type', 'audio/mpeg');
  astream
    .on('data', chunk => {
      console.log('Data chunck received >> ');

    })

  astream
    .on('end', chunk => {
      console.log('end >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });
    })


  astream
    .on('error', chunk => {
      ///  console.log('Data chunck received >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });
    })

    .pipe(res);
})




let myQueue = []

router.post('/save/:id', async (req, res) => {
  isUrl = true;
  let err = {};
  let SONG = {}
  err.error_fields = []
  let xxx ={}
  let myvid =[]
  console.log('video url >> ', videoID + req.params.id);
  myurl = req.body.url;

  console.log('video object >> ', req.body);

  if (!ytdl.validateID(myurl) && !ytdl.validateURL(myurl)) {

isUrl = false

  }else{
    console.log("ytdl join",isUrl)
       var getInfo = await ytdl.getInfo(extractVideoID(myurl)) .catch(error => {
         if(error){
         console.log("errrrrrrrrrrr")
            err.success = false 
err.error_fields.push("input-url")
    return res.send(err)
         }
             throw error

       })


      let songInfo =  getInfo.videoDetails
     xxx = {
    thumbnail: {
        url: songInfo.thumbnails[0].url,
    },
    title: songInfo.title,
    duration:songInfo.lengthSeconds*1000,
    duration_formatted: millisToDuration(songInfo.lengthSeconds*1000),
    channel: {
        name: songInfo.author.name,
    },

    id: songInfo.videoId,
};

       
     myQueue.push(xxx)
  myvid.push(xxx)

///console.log("00000000",videoID+extractVideoID(myurl))
//console.log("00055555500000",songInfo.videoDetails)
  
  
  }
  if (!isUrl){


   myvid = await YouTube.search(isUrl && req.body.name ?req.body.name:myurl, { limit:isUrl ? 1 :5 }).catch(console.error);
  }

 let searched = myvid[0]
///console.log(myvid)

  if (myvid.length == 0) {
    err.success = false 
err.error_fields.push("input-url")
    return res.send(err)
  }

  if (myvid.length>1 ){
    SONG.list = myvid
    SONG.isUrl = isUrl
    SONG.success = true
    return res.send(SONG)
  }

  myurl = searched.id 
console.log(900000 < searched.duration)
  if (900000 < searched.duration){
  err.success = false 
err.error_fields.push("input-url")
err.msg=("too long")

    return res.send(err)
      
  }

  

  




    if (!fs.existsSync(__dirname + `/mp3/${myurl}.ogg`)) {
console.log("not found")
    }else{
      
      console.log("founded")
 fs.unlinkSync(__dirname + `/mp3/${myurl}.ogg`)
 alert("removed")
    }

  
    alert(searched)

let tempn = randomString(8)
  const astream = ytdl(myurl, { encoderArgs: ['-af','dynaudnorm=f=200'], fmt: 'mp3', opusEncoded: false , filter: "audioonly"});

  astream
    .on('start', chunk => {
      console.log("started")
      //  console.log('Data chunck received >> ', chunk);
      // fs.createWriteStream('.//mp3/'+req.params.id+".ogg").write(chunk)
    })


  astream
    .on('data', chunk => {
      //  console.log('Data chunck received >> ', chunk);
      // fs.createWriteStream('.//mp3/'+req.params.id+".ogg").write(chunk)
    })

  astream
    .on('end', chunk => {
      console.log('end >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });

      // res.send("Saved")
      if (myQueue.length > 0) {
        console.log("new q start but imit wait?")
      }
    })


  astream
    .on('error', chunk => {
      console.log('Data chunck received >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });
      
      return res.send(false)


    })

    .pipe(fs.createWriteStream(__dirname +`/mp3/${tempn}.ogg`)
    .on('error', chunk => {
      console.log('err handle >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });
       fs.unlinkSync(__dirname + `/mp3/${tempn}.ogg`)

      return res.send(false)


    })).on('finish',async chunk => {
      console.log('finish >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });

      ///res.send(__dirname +`/mp3/${req.params.id}.ogg`);
    //  await hook.sendFile(__dirname + `/mp3/${tempn}.ogg`);

      fs.rename(__dirname + `/mp3/${tempn}.ogg`, __dirname + `/mp3/${searched.id}.ogg`, function(err) {
    if ( err ) console.log('ERROR: ' + err);
});


//res.redirect(__dirname + `/mp3/${req.params.id}.ogg`, 200);
      


/*
hook.send( ).then((msg) => {
  console.log(msg)
});
*/


     // var readStream = fs.createReadStream(__dirname + `//mp3/${req.params.id}.ogg`);


 /// readStream.pipe(res)
console.log(searched.title)
       var ch = client.channels.cache.get('947760978655854633')
/*
   const filt = client.db.builder().select().from('song').where({ track_id: searched.id });
   let xxx = await client.db.query(filt);
      if(xxx.length>0){
 searched.dl = xxx[0].url
   SONG.current = searched
SONG.list = myvid

  res.send(SONG)
    return  ch.send(`**${searched.title}**`+"\n"+xxx[0].url)  
      }
      */
 ch.send(`**${searched.title}**`,{
   /*
  embed: {
    thumbnail: {
         url: 'attachment://file.jpg'
      }
   },
   */
   files: [{
      attachment: __dirname + `/mp3/${searched.id}.ogg`,
      name: searched.id+".ogg"
   }]
}).then(async (msg) => {
   searched.dl = msg.attachments.array()[0].attachment
   SONG.current = searched
SONG.list = myvid

 res.send(SONG)
console.log(msg.attachments.array()[0].attachment)
    
/*
   if(!xxx.length){
 const builder = client.db.builder().insert('song', { track_id:searched.id,msg_id:msg.id,url:msg.attachments.array()[0].attachment,name:searched.title })
  await client.db.query(builder);
 }
 */
       fs.unlinkSync(__dirname + `/mp3/${searched.id}.ogg`)
    
 })
 
    })




  /*
  if (myQueue.length >0){
    console.log("added to queqe")
    myQueue.push(searched)
  
  }else{
  
  
    viddownload(myQueue[0],req,res)
  }
  
  
  
    let checkurl = isValidURL(myurl)
  console.log(checkurl)
  */

})

function isValidURL(url) {
  return /^https?:\/\/((([a-z\d]([a-z\d-]*[a-z\d])*)\.)+[a-z]{2,}|((\d{1,3}\.){3}\d{1,3}))(:\d+)?(\/[-a-z\d%_.~+]*)*(\?[;&a-z\d%_.~+=-]*)?(#[-a-z\d_]*)?$/i
    .test(url);
}

function extractVideoID(url) {
  var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
  var match = url.match(regExp);
  if (match && match[7].length == 11) {
    return match[7];
  } else {
    return (url);
  }
}

/*
var YoutubeMp3Downloader = require("youtube-mp3-downloader");

//Configure YoutubeMp3Downloader with your settings
var YD = new YoutubeMp3Downloader({
    "ffmpegPath": "/home/runner/BleakDecisiveRule/node_modules/@ffmpeg-installer/linux-x64/ffmpeg",        // FFmpeg binary location
    "outputPath": "./test",    // Output file location (default: the home directory)
    "youtubeVideoQuality": "highestaudio",  // Desired video quality (default: highestaudio)
    "queueParallelism": 2,                  // Download parallelism (default: 1)
    "progressTimeout": 2000,                // Interval in ms for the progress reports (default: 1000)
    "allowWebm": false                      // Enable download from WebM sources (default: false)
});
YD.download("Vhd6Kc4TZls");

YD.on("finished", function(err, data) {
    console.log(JSON.stringify(data));
});


YD.on("progress", function(progress) {
    console.log(JSON.stringify(progress));
});

*/

function viddownload(obj, req, res) {





}




router.get('/download/:id', async (req, res) => {
  console.log('video url >> ', videoID + req.params.id);
  myurl = req.params.id;
  if (!ytdl.validateID(myurl) && !ytdl.validateURL(myurl)) {

    return res.send(false)
  }

  let myvid = await YouTube.search(myurl, { limit: 1 })

    .catch(console.error);

  let searched = myvid[0]


  if (myvid.length == 0) {
    return res.send("novide catched")
  }
  myQueue.push(searched)

  const astream = ytdl(myurl, {
    quality: "highestaudio"
  });


  astream
    .on('start', chunk => {
      console.log("started")
      //  console.log('Data chunck received >> ', chunk);
      // fs.createWriteStream('.//mp3/'+req.params.id+".ogg").write(chunk)
    })


  astream
    .on('data', chunk => {
      //  console.log('Data chunck received >> ', chunk);
      // fs.createWriteStream('.//mp3/'+req.params.id+".ogg").write(chunk)
    })

  astream
    .on('end', chunk => {
      console.log('end >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });

      // res.send("Saved")
      if (myQueue.length > 0) {
        console.log("new q start but imit wait?")
      }
    })


  astream
    .on('error', chunk => {
      console.log('Data chunck received >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });
      return res.send(false)


    })

    .pipe(fs.createWriteStream(__dirname + `//mp3/${req.params.id}.ogg`)).on('finish', chunk => {
      console.log('finish >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });

      ///res.send(__dirname +`/mp3/${req.params.id}.ogg`);


    })

res.download(__dirname +`//mp3/${req.params.id}.ogg`,searched.title);



  /*
  if (myQueue.length >0){
    console.log("added to queqe")
    myQueue.push(searched)
  
  }else{
  
  
    viddownload(myQueue[0],req,res)
  }
  
  
  
    let checkurl = isValidURL(myurl)
  console.log(checkurl)
  */

})




router.post('/search/:id', async (req, res) => {
  let err = {};
  let SONG = {}
  err.error_fields = []
  console.log('video url >> ', videoID + req.params.id);
  myurl = req.body.url;

  console.log('video object >> ', req.body);
/*
  if (!ytdl.validateID(myurl) && !ytdl.validateURL(myurl)) {
err.success = false 
err.error_fields.push("input-url")
    return res.send(err)
  }
*/
  let myvid = await YouTube.search(myurl, { limit: 5 })

    .catch(console.error);

  let searched = myvid[0]
console.log(myvid)

  if (myvid.length == 0) {
    return res.send(false)
  }

  myurl = searched.id 
/*
  if (540000 < searched.duration){
    return res.send("too longest")
  
  }

  */

    if (!fs.existsSync(__dirname + `/mp3/${myurl}.ogg`)) {
console.log("not found")
    }else{
      
      console.log("founded")
 fs.unlinkSync(__dirname + `/mp3/${myurl}.ogg`)
 alert("removed")
    }

  extractVideoID(myurl)
  
    alert(searched)

  myQueue.push(searched)
let tempn = randomString(8)
  const astream = ytdl(myurl,{ encoderArgs: ['-af','dynaudnorm=f=200'], fmt: 'mp3', opusEncoded: false , filter: "audioonly"});

  astream
    .on('start', chunk => {
      console.log("started")
      //  console.log('Data chunck received >> ', chunk);
      // fs.createWriteStream('.//mp3/'+req.params.id+".ogg").write(chunk)
    })


  astream
    .on('data', chunk => {
      //  console.log('Data chunck received >> ', chunk);
      // fs.createWriteStream('.//mp3/'+req.params.id+".ogg").write(chunk)
    })

  astream
    .on('end', chunk => {
      console.log('end >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });

      // res.send("Saved")
      if (myQueue.length > 0) {
        console.log("new q start but imit wait?")
      }
    })


  astream
    .on('error', chunk => {
      console.log('Data chunck received >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });
      
      return res.send(false)


    })

    .pipe(fs.createWriteStream(__dirname +`/mp3/${tempn}.ogg`)
    .on('error', chunk => {
      console.log('err handle >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });
       fs.unlinkSync(__dirname + `/mp3/${tempn}.ogg`)

      return res.send(false)


    })).on('finish',async chunk => {
      console.log('finish >> ', chunk);
      // fs.routerendFile('.//mp3/new_media.ogg', chunk, err => {
      //   if(err) throw err;
      // });

      ///res.send(__dirname +`/mp3/${req.params.id}.ogg`);
    //  await hook.sendFile(__dirname + `/mp3/${tempn}.ogg`);

      fs.rename(__dirname + `/mp3/${tempn}.ogg`, __dirname + `/mp3/${searched.id}.ogg`, function(err) {
    if ( err ) console.log('ERROR: ' + err);
});

SONG.current = searched
SONG.list = myvid

 res.send(SONG)
//res.redirect(__dirname + `/mp3/${req.params.id}.ogg`, 200);
      


/*
hook.send( ).then((msg) => {
  console.log(msg)
});
*/


     // var readStream = fs.createReadStream(__dirname + `//mp3/${req.params.id}.ogg`);


 /// readStream.pipe(res)

    })




  /*
  if (myQueue.length >0){
    console.log("added to queqe")
    myQueue.push(searched)
  
  }else{
  
  
    viddownload(myQueue[0],req,res)
  }
  
  
  
    let checkurl = isValidURL(myurl)
  console.log(checkurl)
  */

})


function randomString(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
}

function millisToDuration(ms) {
        return prettyMilliseconds(ms, { colonNotation: true, secondsDecimalDigits: 0 });
    }
module.exports = router;
