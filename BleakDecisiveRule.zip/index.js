const ytdl = require('ytdl-core');
const fs = require('fs');
var path = require('path');
var timeout = require('express-timeout-handler');
const rateLimit = require('express-rate-limit')



const createAccountLimiter = rateLimit({
	windowMs: 60 * 1 * 1000, // 1 hour
	max: 15, // Limit each IP to 5 create account requests per `window` (here, per hour)
	message:
		'server down',
	standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
	legacyHeaders: false, // Disable the `X-RateLimit-*` headers
})


/*
const hook = new Webhook('https://discord.com/api/webhooks/945552995087712286/8vCh6lvi93sOxDHcQ95dHlrKN5VTiyLHHIESLHUL_s4jWV9MOpbhiUq2nFr9e8a1TRsP');
*/

var progress = require('progress-stream');
const expressLayouts = require('express-ejs-layouts');
var session = require('express-session');
var bodyParser = require('body-parser');
var cors = require('cors')

const express = require('express');
let fetch = require('undici');

const app = express();


//const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;

///const ffmpeg = require('fluent-ffmpeg');
//ffmpeg.setFfmpegPath(ffmpegPath);


var options = {

  // Optional. This will be the default timeout for all endpoints.
  // If omitted there is no default timeout on endpoints
  timeout: 30000,

  // Optional. This function will be called on a timeout and it MUST
  // terminate the request.
  // If omitted the module will end the request with a default 503 error.
  onTimeout: function(req, res) {
    res.status(503).send('Service unavailable. Please retry.');
  },


  onDelayedResponse: function(req, method, args, requestTime) {
    console.log(`Attempted to call ${method} after timeout`)
  },


  disable: ['write', 'setHeaders', 'send', 'json', 'end']
};

///app.use(timeout.handler(options));
app.use(bodyParser.urlencoded({extended : true}));
app.use(
    session({
        secret: "secret",
        resave: true,
        saveUninitialized: true,
    })
);
app.use(cors())

app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'src')));
app.use(express.static(__dirname + '/routes/mp3'));
app.use('/',createAccountLimiter, require('./routes/index.js'));

//console.log(ffmpegPath)




 process.on('unhandledRejection', (reason, p) => {
    console.log('\n\n\n\n\n=== unhandled Rejection ==='.toUpperCase());
    console.log('Reason: ', reason.stack ? String(reason.stack) : String(reason));
    console.log('=== unhandled Rejection ===\n\n\n\n\n'.toUpperCase());
  });
  process.on("uncaughtException", (err, origin) => {
    console.log('\n\n\n\n\n\n=== uncaught Exception ==='.toUpperCase());
    console.log('Exception: ', err.stack ? err.stack : err)
    console.log('=== uncaught Exception ===\n\n\n\n\n'.toUpperCase());
  })
  process.on('uncaughtExceptionMonitor', (err, origin) => {
    console.log('=== uncaught Exception Monitor ==='.toUpperCase());
  });
  process.on('multipleResolves', (type, promise, reason) => {
    /*
      console.log('\n\n\n\n\n=== multiple Resolves ==='.toUpperCase().yellow.dim);
      console.log(type, promise, reason);
      console.log('=== multiple Resolves ===\n\n\n\n\n'.toUpperCase().yellow.dim);
    */
  });
app.use((req, res, next)=> {
  console.log('I run on every request!');
  next();
})
require('./bot/bot')
app.use('/crossdomain.xml', express.static(path.join(__dirname, 'crossdomain.xml')))

app.listen(80, () => console.log('Example app listening on port 3000!'));

